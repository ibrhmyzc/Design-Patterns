public interface Observer {
    void update();
    void display();
}
