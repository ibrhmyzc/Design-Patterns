import java.util.ArrayList;

public class Newspaper implements Subject {

    private ArrayList<Observer> observers;
    private String text;
    private String photo;
    private String audio;

    public Newspaper() {
        observers = new ArrayList<>();
    }

    @Override
    public void add(Observer o) {
        observers.add(o);
    }

    @Override
    public void remove(Observer o) {
    int i = observers.indexOf(o);
        if(i >= 0 )
            observers.remove(i);
    }

    @Override
    public void notifyObservers() {
        for(Observer ob : this.observers)
            ob.update();
    }

    public void newContent(String text, String photo, String audio) {
        this.text = text;
        this.photo = photo;
        this.audio = audio;
        notifyObservers();
    }

    public void setText(String text){
        this.text = text;
        notifyObservers();
    }

    public void setPhoto(String photo){
        this.photo = photo;
        notifyObservers();
    }

    public void setAudio(String audio){
        this.audio = audio;
        notifyObservers();
    }

    public String getText(){
        return text;
    }

    public String getPhoto(){
        return photo;
    }

    public String getAudio(){
        return audio;
    }

}
