package sample;

public interface SolutionStrategy {
    public StringBuilder solve();
}
